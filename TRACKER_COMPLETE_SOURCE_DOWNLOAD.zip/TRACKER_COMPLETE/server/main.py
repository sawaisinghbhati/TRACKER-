import os, json, base64
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from google import genai
from google.genai import types
app=FastAPI(title='TRACKER AI API')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
@app.get('/health')
def health(): return {'status':'ok','service':'TRACKER AI'}
@app.post('/analyze')
async def analyze(subject:str=Form(...),images:list[UploadFile]=File(...)):
    key=os.getenv('GEMINI_API_KEY')
    if not key: raise HTTPException(503,'GEMINI_API_KEY सर्वर में सेट नहीं है')
    if not images or len(images)>20: raise HTTPException(400,'1 से 20 फोटो चुनें')
    parts=[types.Part.from_text(text=f'''आप एक सावधान परीक्षा-शिक्षक हैं। विषय: {subject}। सभी संलग्न फोटो में दिख रहे हर प्रश्न को पढ़ें। कोई जानकारी अस्पष्ट हो तो अनुमान न लगाएँ और confidence low रखें। केवल JSON लौटाएँ, Markdown नहीं। संरचना: {{"items":[{{"question":"","user_answer":"","correct_answer":"","solution":"","mistake_reason":"","chapter":"","memory_point":"","practice_question":"","confidence":"high|medium|low","notes":""}}]}}''')]
    for f in images:
        data=await f.read()
        if len(data)>12*1024*1024: raise HTTPException(413,'हर फोटो अधिकतम 12 MB हो')
        mime=f.content_type or 'image/jpeg'
        parts.append(types.Part.from_bytes(data=data,mime_type=mime))
    try:
        client=genai.Client(api_key=key)
        response=client.models.generate_content(model=os.getenv('GEMINI_MODEL','gemini-2.5-flash-lite'),contents=[types.Content(role='user',parts=parts)],config=types.GenerateContentConfig(response_mime_type='application/json',temperature=0.1))
        parsed=json.loads(response.text or '{}')
        return parsed if isinstance(parsed,dict) and isinstance(parsed.get('items'),list) else {'items':[]}
    except Exception as e: raise HTTPException(502,'AI विश्लेषण विफल: '+str(e)[:300])
