TRACKER — मोबाइल PWA + Gemini AI API

क्या उपलब्ध है:
- Physics, Zoology, Botany, Chemistry
- याद रखने वाले पॉइंट्स, Exercise Questions, Mock Test श्रेणियाँ
- मैन्युअल रिकॉर्ड, विषय/सेक्शन फ़िल्टर, रिकॉर्ड हटाना
- कई फोटो एक साथ Gemini AI को भेजना; AI उत्तर की समीक्षा के बाद सेव करना
- JSON बैकअप और रीस्टोर
- PWA manifest/service worker

सीमाएँ:
- यह सोर्स कोड है, APK या लाइव ऐप नहीं।
- रिकॉर्ड अभी उसी ब्राउज़र के localStorage में हैं; cloud sync/login नहीं है।
- AI के लिए Render पर API सर्वर deploy करना और GEMINI_API_KEY को Render Environment में डालना जरूरी है। API key को GitHub या HTML में कभी न डालें।
- AI के उत्तरों को हमेशा जाँचें; शत-प्रतिशत शुद्धता की गारंटी नहीं।
- Render free tier की उपलब्धता/नींद/सीमाएँ बदल सकती हैं।

Static web: www फ़ोल्डर को HTTPS static hosting पर publish करें।
AI API: Render पर इस repo का Blueprint deploy करें; root render.yaml है।
फिर www/index.html में AI सर्वर URL भरें।
Android install: HTTPS लिंक Chrome में खोलें > ⋮ > Add to Home screen / Install app.
