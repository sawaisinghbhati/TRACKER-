यह संस्करण PWA है; इसे Chrome से Android होम स्क्रीन पर इंस्टॉल किया जा सकता है। Native APK बनाने के लिए Android Studio/Capacitor और कंप्यूटर या cloud build की आवश्यकता होगी। अभी APK शामिल नहीं है।
